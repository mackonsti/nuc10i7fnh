/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20250404 (64-bit version)
 * Copyright (c) 2000 - 2025 Intel Corporation
 *
 * Disassembling to symbolic ASL+ operators
 *
 * Disassembly of SSDT-4.aml
 *
 * Original Table Header:
 *     Signature        "SSDT"
 *     Length           0x0000115C (4444)
 *     Revision         0x02
 *     Checksum         0x1E
 *     OEM ID           "INTEL"
 *     OEM Table ID     "NUC9i5FN"
 *     OEM Revision     0x00000042 (66)
 *     Compiler ID      "INTL"
 *     Compiler Version 0x20160527 (538314023)
 */

DefinitionBlock ("SSDT-4.aml", "SSDT", 2, "INTEL", "NUC9i5FN", 0x00000000)
{
    External (_SB_.AAC0, UnknownObj)
    External (_SB_.ACRT, UnknownObj)
    External (_SB_.APSV, UnknownObj)
    External (_SB_.DTSE, UnknownObj)
    External (_SB_.PCI0.LPCB.H_EC.ECAV, IntObj)
    External (_SB_.PCI0.LPCB.H_EC.ECMD, MethodObj)    // 1 Arguments
    External (_SB_.PCI0.LPCB.H_EC.ECWT, MethodObj)    // 2 Arguments
    External (_SB_.PCI0.LPCB.H_EC.PECH, FieldUnitObj)
    External (_SB_.PCI0.LPCB.H_EC.PECL, FieldUnitObj)
    External (_SB_.PCI0.LPCB.H_EC.PENV, FieldUnitObj)
    External (_SB_.PCI0.LPCB.H_EC.PLMX, FieldUnitObj)
    External (_SB_.PDTS, UnknownObj)
    External (_SB_.PKGA, UnknownObj)
    External (_SB_.PR00, UnknownObj)
    External (_SB_.PR01, UnknownObj)
    External (_SB_.PR02, UnknownObj)
    External (_SB_.PR03, UnknownObj)
    External (_SB_.PR04, UnknownObj)
    External (_SB_.PR05, UnknownObj)
    External (_SB_.PR06, UnknownObj)
    External (_SB_.PR07, UnknownObj)
    External (_SB_.PR08, UnknownObj)
    External (_SB_.PR09, UnknownObj)
    External (_SB_.PR10, UnknownObj)
    External (_SB_.PR11, UnknownObj)
    External (_SB_.PR12, UnknownObj)
    External (_SB_.PR13, UnknownObj)
    External (_SB_.PR14, UnknownObj)
    External (_SB_.PR15, UnknownObj)
    External (_SB_.PR16, UnknownObj)
    External (_SB_.PR17, UnknownObj)
    External (_SB_.PR18, UnknownObj)
    External (_SB_.PR19, UnknownObj)
    External (AC0F, IntObj)
    External (AC1F, IntObj)
    External (ACT1, IntObj)
    External (ACTT, IntObj)
    External (CRTT, IntObj)
    External (CTYP, IntObj)
    External (DPTF, IntObj)
    External (ECON, IntObj)
    External (PSVT, IntObj)
    External (TC1V, IntObj)
    External (TC2V, IntObj)
    External (TCNT, IntObj)
    External (TSPV, IntObj)
    External (VFN0, IntObj)
    External (VFN1, IntObj)
    External (VFN2, IntObj)
    External (VFN3, IntObj)
    External (VFN4, IntObj)

    Scope (\_TZ)
    {
        Name (ETMD, One)
        Event (FCET)
        Name (FCRN, Zero)
        Mutex (FCMT, 0x00)
        Name (CVF0, Zero)
        Name (CVF1, Zero)
        Name (CVF2, Zero)
        Mutex (FMT0, 0x00)
        Mutex (FMT1, 0x00)
        Mutex (FMT2, 0x00)
        PowerResource (FN00, 0x00, 0x0000)
        {
            Method (_STA, 0, Serialized)  // _STA: Status
            {
                Local1 = Zero
                Local0 = Acquire (FMT0, 0x03E8)
                If ((Local0 == Zero))
                {
                    Local1 = CVF0 /* \_TZ_.CVF0 */
                    Release (FMT0)
                }

                Return (Local1)
            }

            Method (_ON, 0, Serialized)  // _ON_: Power On
            {
                Local0 = Acquire (FMT0, 0x03E8)
                If ((Local0 == Zero))
                {
                    CVF0 = One
                    Release (FMT0)
                }

                FNCL ()
            }

            Method (_OFF, 0, Serialized)  // _OFF: Power Off
            {
                Local0 = Acquire (FMT0, 0x03E8)
                If ((Local0 == Zero))
                {
                    CVF0 = Zero
                    Release (FMT0)
                }

                FNCL ()
            }
        }

        Device (FAN0)
        {
            Name (_HID, EisaId ("PNP0C0B") /* Fan (Thermal Solution) */)  // _HID: Hardware ID
            Name (_UID, Zero)  // _UID: Unique ID
            Name (_PR0, Package (0x01)  // _PR0: Power Resources for D0
            {
                FN00
            })
        }

        PowerResource (FN01, 0x00, 0x0000)
        {
            Method (_STA, 0, Serialized)  // _STA: Status
            {
                Local1 = Zero
                Local0 = Acquire (FMT1, 0x03E8)
                If ((Local0 == Zero))
                {
                    Local1 = CVF1 /* \_TZ_.CVF1 */
                    Release (FMT1)
                }

                Return (Local1)
            }

            Method (_ON, 0, Serialized)  // _ON_: Power On
            {
                Local0 = Acquire (FMT1, 0x03E8)
                If ((Local0 == Zero))
                {
                    CVF1 = One
                    Release (FMT1)
                }

                FNCL ()
            }

            Method (_OFF, 0, Serialized)  // _OFF: Power Off
            {
                Local0 = Acquire (FMT1, 0x03E8)
                If ((Local0 == Zero))
                {
                    CVF1 = Zero
                    Release (FMT1)
                }

                FNCL ()
            }
        }

        Device (FAN1)
        {
            Name (_HID, EisaId ("PNP0C0B") /* Fan (Thermal Solution) */)  // _HID: Hardware ID
            Name (_UID, One)  // _UID: Unique ID
            Name (_PR0, Package (0x01)  // _PR0: Power Resources for D0
            {
                FN01
            })
        }

        PowerResource (FN02, 0x00, 0x0000)
        {
            Method (_STA, 0, Serialized)  // _STA: Status
            {
                Local1 = Zero
                Local0 = Acquire (FMT2, 0x03E8)
                If ((Local0 == Zero))
                {
                    Local1 = CVF2 /* \_TZ_.CVF2 */
                    Release (FMT2)
                }

                Return (Local1)
            }

            Method (_ON, 0, Serialized)  // _ON_: Power On
            {
                Local0 = Acquire (FMT2, 0x03E8)
                If ((Local0 == Zero))
                {
                    CVF2 = One
                    Release (FMT2)
                }

                FNCL ()
            }

            Method (_OFF, 0, Serialized)  // _OFF: Power Off
            {
                Local0 = Acquire (FMT2, 0x03E8)
                If ((Local0 == Zero))
                {
                    CVF2 = Zero
                    Release (FMT2)
                }

                FNCL ()
            }
        }

        Device (FAN2)
        {
            Name (_HID, EisaId ("PNP0C0B") /* Fan (Thermal Solution) */)  // _HID: Hardware ID
            Name (_UID, 0x02)  // _UID: Unique ID
            Name (_PR0, Package (0x01)  // _PR0: Power Resources for D0
            {
                FN02
            })
        }

        Method (FNCL, 0, NotSerialized)
        {
            Local5 = Acquire (FCMT, 0x03E8)
            If ((Local5 == Zero))
            {
                Local6 = FCRN /* \_TZ_.FCRN */
                Release (FCMT)
            }

            If ((Local6 != Zero))
            {
                Signal (FCET)
            }
            Else
            {
                Local5 = Acquire (FCMT, 0x03E8)
                If ((Local5 == Zero))
                {
                    FCRN = One
                    Release (FCMT)
                }

                Local5 = Zero
                While ((Local5 < 0x04))
                {
                    If ((Wait (FCET, 0x05) != Zero))
                    {
                        Local5 = 0x04
                    }
                    Else
                    {
                        Local5++
                    }
                }

                Local5 = Acquire (FCMT, 0x03E8)
                If ((Local5 == Zero))
                {
                    FCRN = Zero
                    Release (FCMT)
                }
            }

            Local0 = Zero
            Local1 = Zero
            Local2 = Zero
            Local5 = Acquire (FMT0, 0x03E8)
            If ((Local5 == Zero))
            {
                Local0 = CVF0 /* \_TZ_.CVF0 */
                Release (FMT0)
            }

            Local5 = Acquire (FMT1, 0x03E8)
            If ((Local5 == Zero))
            {
                Local1 = CVF1 /* \_TZ_.CVF1 */
                Release (FMT1)
            }

            Local5 = Acquire (FMT2, 0x03E8)
            If ((Local5 == Zero))
            {
                Local2 = CVF2 /* \_TZ_.CVF2 */
                Release (FMT2)
            }

            \VFN0 = Local0
            \VFN1 = Local1
            \VFN2 = Local2
            If ((\_SB.PCI0.LPCB.H_EC.ECAV && ETMD))
            {
                If (((Local0 != Zero) && (Local1 != Zero)))
                {
                    \_SB.PCI0.LPCB.H_EC.ECWT (AC0F, RefOf (\_SB.PCI0.LPCB.H_EC.PENV))
                }
                ElseIf (((Local0 == Zero) && (Local1 != Zero)))
                {
                    \_SB.PCI0.LPCB.H_EC.ECWT (AC1F, RefOf (\_SB.PCI0.LPCB.H_EC.PENV))
                }
                Else
                {
                    \_SB.PCI0.LPCB.H_EC.ECWT (Zero, RefOf (\_SB.PCI0.LPCB.H_EC.PENV))
                }

                \_SB.PCI0.LPCB.H_EC.ECMD (0x1A)
            }
        }

        ThermalZone (TZ00)
        {
            Name (PTMP, 0x0BB8)
            Method (_SCP, 1, Serialized)  // _SCP: Set Cooling Policy
            {
                \CTYP = Arg0
            }

            Method (_CRT, 0, Serialized)  // _CRT: Critical Temperature
            {
                If (CondRefOf (\_SB.ACRT))
                {
                    If ((\_SB.ACRT != Zero))
                    {
                        Return ((0x0AAC + (\_SB.ACRT * 0x0A)))
                    }
                }

                If ((DPTF == Zero))
                {
                    Return ((0x0AAC + (\CRTT * 0x0A)))
                }
            }

            Method (_TMP, 0, Serialized)  // _TMP: Temperature
            {
                OperationRegion (FNTP, SystemMemory, 0xFE410400, 0x0100)
                Field (FNTP, DWordAcc, NoLock, Preserve)
                {
                    Offset (0x0B),
                    ECCT,   8
                }

                If ((ECCT != 0xFF))
                {
                    Local0 = ECCT /* \_TZ_.TZ00._TMP.ECCT */
                    Local0 = (0x0AAC + (Local0 * 0x0A))
                    PTMP = Local0
                    Return (Local0)
                }

                Return (0x0BC2)
            }

            Method (XPSL, 0, Serialized)
            {
                If ((\TCNT == 0x14))
                {
                    Return (Package (0x14)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07,
                        \_SB.PR08,
                        \_SB.PR09,
                        \_SB.PR10,
                        \_SB.PR11,
                        \_SB.PR12,
                        \_SB.PR13,
                        \_SB.PR14,
                        \_SB.PR15,
                        \_SB.PR16,
                        \_SB.PR17,
                        \_SB.PR18,
                        \_SB.PR19
                    })
                }

                If ((\TCNT == 0x13))
                {
                    Return (Package (0x13)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07,
                        \_SB.PR08,
                        \_SB.PR09,
                        \_SB.PR10,
                        \_SB.PR11,
                        \_SB.PR12,
                        \_SB.PR13,
                        \_SB.PR14,
                        \_SB.PR15,
                        \_SB.PR16,
                        \_SB.PR17,
                        \_SB.PR18
                    })
                }

                If ((\TCNT == 0x12))
                {
                    Return (Package (0x12)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07,
                        \_SB.PR08,
                        \_SB.PR09,
                        \_SB.PR10,
                        \_SB.PR11,
                        \_SB.PR12,
                        \_SB.PR13,
                        \_SB.PR14,
                        \_SB.PR15,
                        \_SB.PR16,
                        \_SB.PR17
                    })
                }

                If ((\TCNT == 0x11))
                {
                    Return (Package (0x11)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07,
                        \_SB.PR08,
                        \_SB.PR09,
                        \_SB.PR10,
                        \_SB.PR11,
                        \_SB.PR12,
                        \_SB.PR13,
                        \_SB.PR14,
                        \_SB.PR15,
                        \_SB.PR16
                    })
                }

                If ((\TCNT == 0x10))
                {
                    Return (Package (0x10)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07,
                        \_SB.PR08,
                        \_SB.PR09,
                        \_SB.PR10,
                        \_SB.PR11,
                        \_SB.PR12,
                        \_SB.PR13,
                        \_SB.PR14,
                        \_SB.PR15
                    })
                }

                If ((\TCNT == 0x0F))
                {
                    Return (Package (0x0F)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07,
                        \_SB.PR08,
                        \_SB.PR09,
                        \_SB.PR10,
                        \_SB.PR11,
                        \_SB.PR12,
                        \_SB.PR13,
                        \_SB.PR14
                    })
                }

                If ((\TCNT == 0x0E))
                {
                    Return (Package (0x0E)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07,
                        \_SB.PR08,
                        \_SB.PR09,
                        \_SB.PR10,
                        \_SB.PR11,
                        \_SB.PR12,
                        \_SB.PR13
                    })
                }

                If ((\TCNT == 0x0D))
                {
                    Return (Package (0x0D)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07,
                        \_SB.PR08,
                        \_SB.PR09,
                        \_SB.PR10,
                        \_SB.PR11,
                        \_SB.PR12
                    })
                }

                If ((\TCNT == 0x0C))
                {
                    Return (Package (0x0C)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07,
                        \_SB.PR08,
                        \_SB.PR09,
                        \_SB.PR10,
                        \_SB.PR11
                    })
                }

                If ((\TCNT == 0x0B))
                {
                    Return (Package (0x0B)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07,
                        \_SB.PR08,
                        \_SB.PR09,
                        \_SB.PR10
                    })
                }

                If ((\TCNT == 0x0A))
                {
                    Return (Package (0x0A)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07,
                        \_SB.PR08,
                        \_SB.PR09
                    })
                }

                If ((\TCNT == 0x09))
                {
                    Return (Package (0x09)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07,
                        \_SB.PR08
                    })
                }

                If ((\TCNT == 0x08))
                {
                    Return (Package (0x08)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06,
                        \_SB.PR07
                    })
                }

                If ((\TCNT == 0x07))
                {
                    Return (Package (0x07)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05,
                        \_SB.PR06
                    })
                }

                If ((\TCNT == 0x06))
                {
                    Return (Package (0x06)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04,
                        \_SB.PR05
                    })
                }

                If ((\TCNT == 0x05))
                {
                    Return (Package (0x05)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03,
                        \_SB.PR04
                    })
                }

                If ((\TCNT == 0x04))
                {
                    Return (Package (0x04)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02,
                        \_SB.PR03
                    })
                }

                If ((\TCNT == 0x03))
                {
                    Return (Package (0x03)
                    {
                        \_SB.PR00,
                        \_SB.PR01,
                        \_SB.PR02
                    })
                }

                If ((\TCNT == 0x02))
                {
                    Return (Package (0x02)
                    {
                        \_SB.PR00,
                        \_SB.PR01
                    })
                }

                Return (Package (0x01)
                {
                    \_SB.PR00
                })
            }

            Method (XPSV, 0, Serialized)
            {
                If (CondRefOf (\_SB.APSV))
                {
                    If ((\_SB.APSV != Zero))
                    {
                        Return ((0x0AAC + (\_SB.APSV * 0x0A)))
                    }
                }

                Return ((0x0AAC + (\PSVT * 0x0A)))
            }

            Method (XTC1, 0, Serialized)
            {
                Return (\TC1V) /* External reference */
            }

            Method (XTC2, 0, Serialized)
            {
                Return (\TC2V) /* External reference */
            }

            Method (XTSP, 0, Serialized)
            {
                Return (\TSPV) /* External reference */
            }
        }
    }
}

